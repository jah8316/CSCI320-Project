create view pg_config(name, setting) as
SELECT pg_config.name,
       pg_config.setting
FROM pg_config() pg_config(name, setting);

alter table pg_config
    owner to postgres;

